package com.backbase.assignment.solution.util;

public interface ResponseProcessor {

	String filterByCity(String json, String city);

}
