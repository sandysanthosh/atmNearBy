package com.backbase.assignment.solution.util;

public enum Processor {
	RAW, SEARCH
}
